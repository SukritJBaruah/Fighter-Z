Final:

+bug fixes


#################################################################################################################
Beta:

+implememnted stages/ waves of enemy
+ game end message
+ sounds for energy blasts only ( because I havent found other sound resources ) . Ripped from DBZ

#################################################################################################################
Iteration 2:

+new enemies and special attacks + projectiles + animations
+ player special attacks
+ interactions
+ sprites

#################################################################################################################

Iteration 1:

+implemented interaction i.e. punch, runattack kick { damage, injury and fall code + animation to both player and enemy }
+ implemented health bar/energy bar
+ implemented defend code(animation was done earlier)
+ same with rolling, cannot be hit when rolling



+ fixed running code as per feedback, enemy punches delay timing, and other minor bug fixes

#################################################################################################################

Menu + Difficulty :

Implemented a main menu, difficulty menu + help menu + pause menu (improvements will be done later)

Implemented background + enemy (sprites are not done yet so used the same as the player with red tint)

Enemy AI: choose easy for dumb enenmy, medium for less dumber enemy, hard for a really good ai but I've given time before the enemy
	does the first initial attack to keep it relatively easy



#################################################################################################################

Prototype:

up/down/left/right/w/a/s/d - movement walk
double tap horizontal keys - run
7 - defend
6 - attack
space - jump

defend while running to roll
jump while running to leap forward
attack while running to dash attack


#################################################################################################################
~Sukrit Jyoti Baruah

The sprites do not belong to me in anyway, this is just for developing and not finished. Will be changed in Final version.
Credits to Gad from lf-empire.de/forum